#!/usr/bin/env python3
import json, os
def evaluate_model(model_path, data_path=None):
    metrics_file = 'outputs/metrics.json'
    if not os.path.exists(metrics_file):
        return {'error': 'metrics not found'}
    with open(metrics_file) as f:
        metrics = json.load(f)
    return {'metrics': metrics, 'model': model_path}

if __name__ == '__main__':
    import sys, json
    if len(sys.argv)<2:
        print(json.dumps({'error':'pass model path'})); sys.exit(0)
    print(json.dumps(evaluate_model(sys.argv[1], None)))
