import pandas as pd, os
def infer_metadata_from_csv(csv_path):
    df = pd.read_csv(csv_path, nrows=5)
    fs = 1000
    names = list(df.columns)
    return {'fs': fs, 'names': names, 'channels': df.shape[1]}

def plan_pipeline_from_csv(csv_path):
    meta = infer_metadata_from_csv(csv_path)
    fs = meta['fs']; names = meta['names']
    if any('emg' in n.lower() for n in names) or fs>=1000:
        sig = 'emg'
        plan = {'filter':{'low':20,'high':450}, 'notch':50, 'window_ms':250, 'model_candidates':['cnn','lstm','xgboost']}
    elif any('ecg' in n.lower() for n in names) or 100<=fs<1000:
        sig = 'ecg'
        plan = {'filter':{'low':0.5,'high':40}, 'notch':50, 'window_ms':1000, 'model_candidates':['lstm','xgboost']}
    else:
        sig = 'timeseries'
        plan = {'filter':{'low':0.1,'high':50}, 'window_ms':500, 'model_candidates':['xgboost','cnn']}
    plan['signal_type'] = sig
    plan['csv_path'] = os.path.abspath(csv_path)
    return plan
