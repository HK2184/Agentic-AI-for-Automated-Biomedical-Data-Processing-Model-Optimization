#!/usr/bin/env python3
import json, os
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def make_report(metrics_json='outputs/metrics.json', outdir='outputs'):
    with open(metrics_json) as f:
        metrics = json.load(f)
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, 'report.pdf')
    c = canvas.Canvas(path, pagesize=letter)
    c.drawString(50,750, "Biomedical Pipeline Agent - Report")
    y = 700
    for k,v in metrics.items():
        c.drawString(50,y,f"{k}: {v}")
        y -= 20
    c.save()
    return path

if __name__ == '__main__':
    import sys, json
    metrics = sys.argv[1] if len(sys.argv)>1 else 'outputs/metrics.json'
    outdir = sys.argv[2] if len(sys.argv)>2 else 'outputs'
    print(json.dumps({'report': make_report(metrics, outdir)}))
