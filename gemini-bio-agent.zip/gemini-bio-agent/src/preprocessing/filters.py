import numpy as np
from scipy.signal import butter, filtfilt, iirnotch

def bandpass_filter(signal, fs, lowcut, highcut, order=4):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return filtfilt(b, a, signal)

def notch_filter(signal, fs, freq=50.0, Q=30.0):
    w0 = freq / (fs/2)
    b, a = iirnotch(w0, Q)
    return filtfilt(b, a, signal)
