import numpy as np
def sliding_windows(signal, window_size, step_size):
    n = len(signal)
    windows = []
    for start in range(0, n - window_size + 1, step_size):
        windows.append(signal[start:start+window_size])
    return np.stack(windows) if windows else np.empty((0, window_size))
