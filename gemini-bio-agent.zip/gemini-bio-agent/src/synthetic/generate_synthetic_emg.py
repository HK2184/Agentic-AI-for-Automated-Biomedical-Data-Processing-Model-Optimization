#!/usr/bin/env python3
import numpy as np
import pandas as pd
import argparse, os

def generate_emg(duration_s=10, fs=1000, n_channels=1, noise_level=0.1, seed=42):
    np.random.seed(seed)
    t = np.arange(0, duration_s, 1/fs)
    data = {}
    for ch in range(n_channels):
        signal = np.zeros_like(t)
        n_bursts = np.random.randint(3,8)
        for _ in range(n_bursts):
            start = np.random.uniform(0, duration_s-0.5)
            width = np.random.uniform(0.05, 1.0)
            center_idx = int(start*fs)
            width_samples = int(width*fs)
            gauss = np.exp(-0.5 * ((np.arange(len(t)) - center_idx) / (width_samples+1))**2)
            amplitude = np.random.uniform(0.5, 2.0)
            signal += amplitude * gauss
        hf = 0.1 * np.sin(2*np.pi*50*t) + 0.05*np.sin(2*np.pi*120*t)
        signal = signal + 0.2*np.random.randn(len(t))*noise_level + hf
        data[f'ch{ch}'] = signal
    data['time'] = t
    df = pd.DataFrame(data)
    return df

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--duration', type=float, default=10.0)
    parser.add_argument('--fs', type=int, default=1000)
    parser.add_argument('--out', type=str, default='data/synthetic/sample_emg.csv')
    parser.add_argument('--channels', type=int, default=1)
    args = parser.parse_args()
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df = generate_emg(duration_s=args.duration, fs=args.fs, n_channels=args.channels)
    df.to_csv(args.out, index=False)
    print('Synthetic EMG saved to', args.out)
