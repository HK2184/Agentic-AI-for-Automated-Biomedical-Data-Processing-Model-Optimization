import pandas as pd, numpy as np, os, json
from preprocessing.filters import bandpass_filter, notch_filter
from preprocessing.segmentation import sliding_windows
from feature_engineering.stats_features import time_domain_features

def run_full_preprocessing(csv_path, channel=0, fs=1000, plan=None):
    df = pd.read_csv(csv_path)
    signal = df[df.columns[channel]].to_numpy()
    if plan is None:
        plan = {'filter':{'low':20,'high':450}, 'notch':50, 'window_ms':250}
    sig = bandpass_filter(signal, fs, plan['filter']['low'], plan['filter']['high'])
    if plan.get('notch'):
        sig = notch_filter(sig, fs, plan['notch'])
    out = {'n_samples': len(sig), 'fs': fs}
    outpath = os.path.join('outputs','preprocessed_channel0.npy')
    os.makedirs('outputs', exist_ok=True)
    np.save(outpath, sig)
    out['path'] = outpath
    return out

def extract_features_from_csv(csv_path, channel=0, fs=1000, plan=None):
    pre = run_full_preprocessing(csv_path, channel, fs, plan)
    sig = np.load(pre['path'])
    win_ms = plan.get('window_ms', 250) if plan else 250
    win_samples = int(fs*win_ms/1000)
    step = max(1, win_samples//2)
    windows = sliding_windows(sig, win_samples, step)
    feats = [time_domain_features(w) for w in windows]
    outpath = os.path.join('outputs','features.json')
    with open(outpath,'w') as f:
        json.dump(feats, f, indent=2)
    return {'n_windows': len(windows), 'features_path': outpath}
