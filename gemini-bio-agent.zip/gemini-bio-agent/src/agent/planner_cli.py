#!/usr/bin/env python3
import sys, json
from agent_planner import plan_pipeline_from_csv
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({"error":"pass csv path"})); sys.exit(0)
    csv_path = sys.argv[1]
    plan = plan_pipeline_from_csv(csv_path)
    print(json.dumps(plan))
