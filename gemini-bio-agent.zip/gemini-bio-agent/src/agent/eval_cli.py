#!/usr/bin/env python3
import sys, json
from evaluator import evaluate_model
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({'error':'pass model path'})); sys.exit(0)
    model_path = sys.argv[1]
    res = evaluate_model(model_path)
    print(json.dumps(res))
