#!/usr/bin/env python3
import sys, json
from trainer import train_from_features
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({'error':'pass features json path'})); sys.exit(0)
    data_path = sys.argv[1]
    res = train_from_features(data_path)
    print(json.dumps(res))
