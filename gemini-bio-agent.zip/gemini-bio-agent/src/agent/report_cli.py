#!/usr/bin/env python3
import sys, json
from reporter import make_report
if __name__ == '__main__':
    metrics = sys.argv[1] if len(sys.argv)>1 else 'outputs/metrics.json'
    outdir = sys.argv[2] if len(sys.argv)>2 else 'outputs'
    path = make_report(metrics, outdir)
    print(json.dumps({'report': path}))
