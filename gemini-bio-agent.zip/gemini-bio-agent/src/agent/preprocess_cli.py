#!/usr/bin/env python3
import sys, json
from tool_runner import run_full_preprocessing
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({'error':'pass csv path'})); sys.exit(0)
    csv_path = sys.argv[1]
    out = run_full_preprocessing(csv_path)
    print(json.dumps(out))
