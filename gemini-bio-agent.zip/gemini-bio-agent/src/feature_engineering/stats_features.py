import numpy as np
def time_domain_features(window):
    return {
        "mean": float(np.mean(window)),
        "std": float(np.std(window)),
        "rms": float(np.sqrt(np.mean(window**2))),
        "max": float(np.max(window)),
        "min": float(np.min(window)),
        "range": float(np.max(window) - np.min(window)),
    }
